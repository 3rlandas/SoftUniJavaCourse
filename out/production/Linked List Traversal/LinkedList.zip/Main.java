import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        LinkedList list = new LinkedList();
        while (n-- > 0) {
            String[] input = scanner.nextLine().trim().split("\\s+");
            if ("Add".equals(input[0])) {
                list.add(Integer.parseInt(input[1]));
            } else {
                list.remove(Integer.parseInt(input[1]));
            }
        }
        System.out.println(list.size());
        list.forEach(e -> System.out.print(e + " "));

    }
}