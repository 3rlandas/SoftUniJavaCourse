import java.beans.PropertyEditorSupport;
import java.util.ArrayList;
import java.util.List;

public class Guild {
    private String name;
    private  int capacity;
    private List<Player> roster;

    public Guild(String name, int capacity){
        this.name = name;
        this.capacity = capacity;
        this.roster= new ArrayList<>();
    }
    public void addPlayer(Player player){

        if(this.roster.size() < this.capacity){
            this.roster.add(player);
        }
    }
    public boolean removePlayer(String name){
        return this.roster.remove(name);
    }
    public void promotePlayer(String name){

        this.roster.stream().filter(player -> player.getName().equals(name)).findFirst().ifPresent(player -> player.setRank("Member"));

    }
    public void demotePlayer(String name){

        this.roster.stream().filter(player -> player.getName().equals(name)).findFirst().ifPresent(player -> player.setRank("Trial"));
    }
    public Player[] kickPlayersByClass(String clazz){

        Player[] result = roster.stream().filter(player -> player.getClazz().equals(clazz)).toArray(Player[]::new);
        return result;
    }
    public int count(){
        return this.roster.size();
    }

    public String report(){
        StringBuilder output =  new StringBuilder("Players in the guild: ");

        output.append(getName()).append(":").append(System.lineSeparator());
        getRoster().forEach(player -> output.append(player).append(System.lineSeparator()));

        return output.toString();
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getCapacity() {
        return capacity;
    }
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    public List<Player> getRoster() {
        return roster;
    }
    public void setRoster(List<Player> roster) {
        this.roster = roster;
    }
}
